(def {{name}} :foo)
