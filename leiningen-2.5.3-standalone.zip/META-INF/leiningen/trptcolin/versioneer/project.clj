(defproject trptcolin/versioneer "0.1.1"
  :description "Provides version introspection for Leiningen-generated projects"
  :license {:name "Eclipse Public License"
            :url "http://www.eclipse.org/legal/epl-v10.html"}
  :dependencies [[org.clojure/clojure "1.4.0"]])
